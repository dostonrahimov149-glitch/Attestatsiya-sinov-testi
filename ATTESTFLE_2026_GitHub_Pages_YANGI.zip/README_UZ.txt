# ATTESTFLE 2026 — GitHub Pages

## Fayllar
- `index.html` — sayt va dizayn
- `questions.js` — Word hujjatidan ajratilgan savollar va javob kaliti

## GitHub Pages'ga joylash
1. GitHub'da yangi repository yarating, masalan `attestfle-exam-2026`.
2. ZIP ichidagi `index.html` va `questions.js` fayllarini repository'ning bosh sahifasiga yuklang.
3. Repository → Settings → Pages bo'limiga o'ting.
4. Build and deployment: **Deploy from a branch** ni tanlang.
5. Branch: `main`, folder: `/ (root)` ni tanlab Save bosing.
6. Bir necha daqiqadan keyin GitHub Pages bergan manzilni oching.

## Muhim eslatma
Yuklangan Word hujjatida 1–43 va 45–60 raqamli savollar bor. **44-savol yo‘q**.
Shu sabab sayt 60 ta raqamli o‘rinni ko‘rsatadi, lekin 44-savol vaqtincha bo‘sh joy sifatida belgilanadi va ball hisobiga kiritilmaydi.
44-savolni yuborsangiz, `questions.js` faylini to‘ldirib berish mumkin.

## Javoblar maxfiyligi haqida
Bu oddiy statik GitHub Pages sayti. Javob kaliti `questions.js` ichida bo‘ladi; texnik jihatdan sayt fayllarini ko‘ra oladigan kishi javoblarni topishi mumkin. Bu versiya oddiy mashq/sinov uchun qulay, lekin yuqori xavfsizlik talab qilinadigan rasmiy imtihon uchun server tomoni baholash kerak.


TUZATISH: Javob variantlari alohida A, B, C, D bloklariga ajratildi. 26-savolda ham variantlar topilmagani sababli u vaqtincha mavjud bo‘lmagan savol sifatida ko‘rsatiladi. 44-savol ham avvalgi kabi yetishmaydi.
